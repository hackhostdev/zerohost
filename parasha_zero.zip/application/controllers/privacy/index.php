<?php
class indexController extends Controller {
	public function index() {
		if(!$this->user->isLogged()) {
			$this->response->redirect($this->config->url . 'account/login');
		}
		$this->document->setActiveSection('main');
		$this->document->setActiveItem('index');
		$this->data['title'] = $this->config->title;
		$this->data['description'] = $this->config->description;
		$this->data['keywords'] = $this->config->keywords;
		$this->data['url'] = $this->config->url;

		$this->getChild(array('common/header', 'common/footer'));
		return $this->load->view('privacy/index', $this->data);
	}
}
?>